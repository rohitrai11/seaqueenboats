import { Component, OnInit } from '@angular/core';
import { Boat } from '../boat';
import { BOATS } from '../mock-boat';

@Component({
  selector: 'displayboat',
  templateUrl: './displayboat.component.html',
  styleUrls: ['./displayboat.component.css']
})
export class DisplayboatComponent implements OnInit {
  show
  boatData: Boat[] = BOATS;
displayBoat: Boat;
myclass:string;
g:string="green";
b:string="blue";
flag:boolean=false;
selectedRow:number;
  constructor() { }
  setClickedRow(rowNo:number){

    this.selectedRow=rowNo;

  }
  showBoat(boat: Boat) {
   this.show = this.show ? false : true;
    this.displayBoat = boat;
 }
  changeStyle1(){
    this.flag=this.flag?false:true;
    this.myclass="styleclass1";
  }
  changeStyle2(){
    this.flag=this.flag?false:true;
    this.myclass="styleclass2";
  }
  
//   boat: Boat = {
//     boatId: '1001',
//     boatType: 'Houseboat',
//     location: 'Allepey',
//     allowedDays: null,
//     basePrice: 999.0,
//     discount: 0.066,
//     bookingStart: new Date(new Date().getTime() + 100000000),
//     description: `These boats offer the luxury of living on water 
//     and provide excellentrecreational & holiday accomodation facilities`,
//     message: ''
// };


  ngOnInit() {
  }

}
