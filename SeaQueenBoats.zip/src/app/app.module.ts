import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DisplayboatComponent } from './displayboat/displayboat.component';
import { BoatDetailsComponent } from './boat-details/boat-details.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayboatComponent,
    BoatDetailsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
